# [2.3.0](https://github.com/yamadharma/academic-laboratory-report-template/compare/v2.2.2...v2.3.0) (2026-09-06)

### Features

* **report:** extend report text ([3acaf6e](https://github.com/yamadharma/academic-laboratory-report-template/commit/3acaf6e410b4d9d477c4121e9ac07eb4352a34f1))

## [2.2.2](https://github.com/yamadharma/academic-laboratory-report-template/compare/v2.2.1...v2.2.2) (2026-02-08)


### Bug Fixes

* **resources:** update csl ([3edd2c9](https://github.com/yamadharma/academic-laboratory-report-template/commit/3edd2c9c327fda0a5fa1e9bd341fd5245b1faa97))
* **resourses:** move default.tex ([9c0e6f8](https://github.com/yamadharma/academic-laboratory-report-template/commit/9c0e6f8ad97a265f134dc3839e6c6606c8bd54e3))


### Features

* **quarto:** add support minted ([377114a](https://github.com/yamadharma/academic-laboratory-report-template/commit/377114a40c6eb600f0bb1e01300a6793eb4f3449))



## [2.2.1](https://github.com/yamadharma/academic-laboratory-report-template/compare/v2.2.0...v2.2.1) (2025-10-16)


### Bug Fixes

* **style:** fix loading old plex-otf ([a4f2dd1](https://github.com/yamadharma/academic-laboratory-report-template/commit/a4f2dd1b92502379ea11269074626e2143efa771))



# [2.2.0](https://github.com/yamadharma/academic-laboratory-report-template/compare/v2.1.0...v2.2.0) (2025-09-30)


### Features

* **quarto:** load different packages depending on texlive ([060a044](https://github.com/yamadharma/academic-laboratory-report-template/commit/060a044832aeb6adc93fa0c1d951791ab2d51f62))
* **quarto:** switch to xelatex ([25d8483](https://github.com/yamadharma/academic-laboratory-report-template/commit/25d8483b39a2440d0463c185d055c233b5bc630f))



# [2.1.0](https://github.com/yamadharma/academic-laboratory-report-template/compare/v2.0.2...v2.1.0) (2025-09-06)


### Bug Fixes

* **quarto:** fix compatiblity with tinytex ([c607514](https://github.com/yamadharma/academic-laboratory-report-template/commit/c607514c96e3c43abd4805b96e409f33e464825a))



## [2.0.2](https://github.com/yamadharma/academic-laboratory-report-template/compare/v2.0.1...v2.0.2) (2025-07-01)


### Bug Fixes

* **gitignore:** ignore report output ([1d4fcb5](https://github.com/yamadharma/academic-laboratory-report-template/commit/1d4fcb5c4e60ad5f12ad8320e0589a42952e8a4a))



## [2.0.1](https://github.com/yamadharma/academic-laboratory-report-template/compare/v2.0.0...v2.0.1) (2025-05-14)


### Features

* **report:** add project file ([34680b2](https://github.com/yamadharma/academic-laboratory-report-template/commit/34680b24ba70cf61f0f8def4ce37c40e7e500189))



# [2.0.0](https://github.com/yamadharma/academic-laboratory-report-template/compare/v1.0.5...v2.0.0) (2025-03-29)


### Bug Fixes

* **main:** fix file structure ([f8cf1f2](https://github.com/yamadharma/academic-laboratory-report-template/commit/f8cf1f2b87fb7145c06163d0009750d4b9efaa18))
* **report:** fix biblatex options ([82d1c7e](https://github.com/yamadharma/academic-laboratory-report-template/commit/82d1c7edcfad3973bc6c4e2a1b87f4e9ec651380))
* **report:** update yaml preamble ([e5b6bd8](https://github.com/yamadharma/academic-laboratory-report-template/commit/e5b6bd803a9c46d8fb3ca91f526895becbf4be7f))


### Features

* **report:** add author and affilation ([64a3675](https://github.com/yamadharma/academic-laboratory-report-template/commit/64a3675af31d42703b2cdb7dcc217a8312b5e8a0))
* **report:** add pdf options ([afc8946](https://github.com/yamadharma/academic-laboratory-report-template/commit/afc894638b41a5bdc92a22243266a241ce2f9272))
* **report:** switch to Quarto ([b6b59c9](https://github.com/yamadharma/academic-laboratory-report-template/commit/b6b59c9c4bb2bf9fbfcea8663a0b93124be5caaf))



## [1.0.5](https://github.com/yamadharma/academic-laboratory-report-template/compare/v1.0.4...v1.0.5) (2024-08-31)


### Bug Fixes

* **make:** add biblatex for future ([f18bb2f](https://github.com/yamadharma/academic-laboratory-report-template/commit/f18bb2f6fc80f39f40abd20d276ce7038c7124df))


### Features

* **report:** switch to IBM Plex font ([cedf4d0](https://github.com/yamadharma/academic-laboratory-report-template/commit/cedf4d066120151c776c3a54151d84e06387f4b8))



## [1.0.4](https://github.com/yamadharma/academic-laboratory-report-template/compare/v1.0.3...v1.0.4) (2024-02-08)


### Features

* **make:** switch to pandoc-crossref ([d981950](https://github.com/yamadharma/academic-laboratory-report-template/commit/d981950aca35348a7489076b3f1a61f4b23be4d3))



## [1.0.3](https://github.com/yamadharma/academic-laboratory-report-template/compare/v1.0.2...v1.0.3) (2023-11-05)


### Features

* **report:** switch to xelatex ([b493f6b](https://github.com/yamadharma/academic-laboratory-report-template/commit/b493f6be6af9be6332019a0a680caca77c237b1d))



## [1.0.2](https://github.com/yamadharma/academic-laboratory-report-template/compare/v1.0.1...v1.0.2) (2023-02-07)


### Features

* **filters:** add support pandoc-xnos ([0cd4f9b](https://github.com/yamadharma/academic-laboratory-report-template/commit/0cd4f9b0c3602091c20bb2e3a7f4d3e6fc37b3fd))



## [1.0.1](https://github.com/yamadharma/academic-laboratory-report-template/compare/v1.0.0...v1.0.1) (2022-04-16)


### Bug Fixes

* **yaml:** change `toc_depth` to `toc-depth` ([e1d9c6e](https://github.com/yamadharma/academic-laboratory-report-template/commit/e1d9c6e3da06a4395032b573ad44a96b750bb6ba))


### Features

* **makefile:** switch to lualatex ([d1ff51d](https://github.com/yamadharma/academic-laboratory-report-template/commit/d1ff51db471deb33215c70a11621565103ce9f60))
* **yaml:** add babel support ([f07f5e4](https://github.com/yamadharma/academic-laboratory-report-template/commit/f07f5e44aa3ffc53257313ca03bd59bc4aa8239a))
* **yaml:** add customization to pandoc-crossref ([5805578](https://github.com/yamadharma/academic-laboratory-report-template/commit/5805578925d33cdd57e41d10e1803d901a8d4d9a))
* **yaml:** add indent first paragraph package ([3acab4b](https://github.com/yamadharma/academic-laboratory-report-template/commit/3acab4b91145b640f778bb2b2120aef57768f066))
* **yaml:** remove extra configuration for penalties ([130a2bb](https://github.com/yamadharma/academic-laboratory-report-template/commit/130a2bb5117ae0a26bcabcdb3da19a4310e06d70))



# 1.0.0 (2021-09-13)


### Bug Fixes

* **report:** change lualatex to xelatex ([222a1c6](https://github.com/yamadharma/academic-laboratory-report-template/commit/222a1c6dc83463ee664fa0c7aacce3c440ec073f))


### Features

* **report:** add bibliography support ([963737d](https://github.com/yamadharma/academic-laboratory-report-template/commit/963737df93a51fda70640586d421215b2a392464))




